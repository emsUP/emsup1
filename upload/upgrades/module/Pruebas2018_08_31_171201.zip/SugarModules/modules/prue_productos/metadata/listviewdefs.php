<?php
$module_name = 'prue_productos';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'PRECIO' => 
  array (
    'type' => 'float',
    'label' => 'LBL_PRECIO',
    'width' => '9%',
    'default' => true,
  ),
);
;
?>
